#include "RoadTransition.hpp"

//changes lines for a new frame of the animation
void RoadTransition::newFrame() 
{

}