This currently just displays the main different road states and has code to make all the other graphics (mostly) done.
Press space to rotate through the roads, later on they should be triggered by the distance the car has traveled, 
and will have transition animations.