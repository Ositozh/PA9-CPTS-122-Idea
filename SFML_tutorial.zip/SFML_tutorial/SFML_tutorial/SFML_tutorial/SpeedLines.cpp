#include "SpeedLines.hpp"

//changes lines for a new frame of the animation
void SpeedLines::newFrame() 
{

}