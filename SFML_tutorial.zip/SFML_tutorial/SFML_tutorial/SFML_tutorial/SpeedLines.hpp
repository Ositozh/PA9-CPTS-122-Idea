#pragma once
#include "pa9.hpp"
#include "AnimatedGraphic.hpp"

class SpeedLines : public AnimatedGraphic {
public:
	//compiler constructor and destructor work here
	

	//changes lines for a new frame of the animation
	void newFrame();
};